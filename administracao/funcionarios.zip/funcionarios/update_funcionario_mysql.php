<?php
session_start(); //para utilizar "session" tem de estar aqui no topo e em todos os scripts
require_once "config.php";

$sql = "UPDATE funcionarios
                SET
                    nome = '".$_POST['utilizador']."',
                    data_nascimento = ('".$_POST['datanascimento']."'),
                    bi = ".$_POST['bi'].",
                    data_admicao = '".$_POST['dataadmicao']."',
                    funcao = '".$_POST['funcao']."',
                    endereco = '".$_POST['endereco']."',
                    email = '".$_POST['email']."',
                    cidade = '".$_POST['cidade']."',
                    telemovel = '".$_POST['telemovel']."'
                	WHERE idfuncionarios='".$_POST['idfuncionarios']."'";

            //echo $sql;
            //exit();
                     mysqli_query($link,$sql);


                      mysqli_close($link);
header('Location:/administracao/utilizadores/index.php');
exit();
?>