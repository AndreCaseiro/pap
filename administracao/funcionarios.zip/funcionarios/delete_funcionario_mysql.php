<?php
session_start(); //para utilizar "session" tem de estar aqui no topo e em todos os scripts
require_once "config.php";

$sql = "DELETE FROM funcionarios
			WHERE idfuncionarios='".$_POST['idfuncionarios']."'";

		echo $sql;
		exit();
		mysqli_query($link,$sql);
        mysqli_close($link);
header('Location:/administracao/index.php');
exit();
?>