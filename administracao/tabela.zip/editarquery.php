<?php
include 'conn.php';
 
$id = $_GET['id'];
 
$nome = $_POST['nome'];
$username = $_POST['username'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$numerosage = $_POST['numerosage'];
$password = $_POST['password'];
$password2 = md5($password);


if($password==""){
	$sql = mysqli_query($conn, "UPDATE accounts SET nome='$nome', username='$username', email='$email', telefone='$telefone', numerosage='$numerosage' WHERE id='$id' ");
}else{
	$sql = mysqli_query($conn, "UPDATE accounts SET nome='$nome', username='$username', telefone='$telefone', email='$email', numerosage='$numerosage', password='$password2' WHERE id='$id' ");
}

if($sql){
echo "<script>alert('Conta editada com sucesso'); window.location='index.php'</script>";
}else{
echo "<script>alert('Erro ao editar conta'); window.location='index.php'</script>";
}

									
									
?>