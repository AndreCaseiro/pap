<?php
session_start();
if (isset($_SESSION['admin'])) {
?>

<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Icons -->
	<meta property="og:url" content="http://lipis.github.io/bootstrap-social/" />
    <meta property="og:image" content="http://lipis.github.io/bootstrap-social/assets/img/bootstrap-social.png" />
	<!-- Title -->
    <title>Webmania</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/font-awesome.css" rel="stylesheet">
    <link href="assets/css/docs.css" rel="stylesheet" >
    <link href="bootstrap-social.css" rel="stylesheet" >
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="shortcut icon" type="image/ico" href="images/favicon.ico" sizes="32x32"/>
    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/icofont.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
      #map {
        width: 100%;
        height: 400px;
        background-color: grey;
      }
    </style>
</head>

<body data-spy="scroll" data-target=".mainmenu-area">
    <!--Preloader-->
    <div class="preloader">
        <div class="spinner"></div>
    </div>

    <!-- Mainmenu-Area -->
    <nav class="navbar mainmenu-area" data-spy="affix" data-offset-top="197">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="navbar-header smoth">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainmenu">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="#home-area"><img style="width:100px;height:40px;" src="images/logo2.png" alt=""></a>
                    </div>
                    <div class="collapse navbar-collapse navbar-right" id="mainmenu">
                        <ul class="nav navbar-nav navbar-right help-menu">
							<?php  if (isset($_SESSION['username'])==false) : ?>
                            <li><a href="/users/login.php"><i class="icofont icofont-user-alt-4"></i></a></li>
							<?php endif ?>
							<?php  if (isset($_SESSION['username'])) : ?>
							<li><a href="/users/logout.php"><i class="icofont icofont-user-alt-4"></i><?php echo $_SESSION['username']; ?>, Logout</a></li>
							<?php endif ?>
                        </ul>
                        <ul class="nav navbar-nav primary-menu">
                            <li><a href="/index.php#home-area">Início</a></li>
							<li><a href="/index.php#empresa-area">A Empresa</a></li>
                            <li><a href="/index.php#service-area">Serviços</a></li>
                            <li><a href="/index.php#apoiotecnico-area">Apoio Técnico</a></li>
                            <li><a href="/index.php#contact-area">Contactos</a></li>
							<?php  if (isset($_SESSION['admin'])) : ?>
							<li><a href="/assistencias/index.php">Consultar Assistências</a></li>
							<?php endif ?>
                        </ul>
                    </div>
					<div class="collapse navbar-collapse navbar-right" id="mainmenu">
					<ul class="nav navbar-nav primary-menu">
				<?php  if (isset($_SESSION['username'])) : ?>
							<li><a href="/conta/password.php">Alterar Password</a></li>
							<li><a href="/conta/email.php">Alterar Email</a></li>
							<li><a href="/tickets/index.php">Tickets</a></li>
							<li><a href="/tickets/usertickets/index.php">Consultar Tickets</a></li>
				<?php endif ?>
				<?php  if (isset($_SESSION['admin'])) : ?>
							<li><a href="/tickets/admintickets/index.php">Gestão de Tickets</a></li>
							<li class="active"><a href="index.php">Contas</a></li>
				<?php endif ?>
							</ul>
				</div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Mainmenu-Area-/ -->

	<header class="header-area overlay" id="home-area">
        <div class="vcenter">
            <div class="container">
                <div class="row">
                    <center>
                        <div class="header-text">
                            <div class="wow fadeInUp" data-wow-delay="0.5s">
								<div class="container">
	<div style="height:50px;"></div>
	<div class="well" style="margin:auto;padding:auto;width:100%;height:600;overflow:scroll;">
	<span style="font-size:25px; color:black"><center><strong>Lista de Contas</strong></center></span>	
		<div style="height:20px;"></div>
		<form method="POST" action='delete.php'>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<th></th>
				<th>Username</th>
				<th>Nome</th>
				<th>Email</th>
				<th>Telefone</th>
				<th>Nº Cliente SAGE</th>
				<th>Estado</th>
				<th>Tipo</th>
			</thead>
			<tbody>
			<?php
				include('conn.php');
				
				$username = $_SESSION['username'];
				//header("Content-Type: text/html; charset=ISO-8859-1",true);
				$query=mysqli_query($conn,"SELECT * FROM accounts ORDER BY id ASC");
				while($row=mysqli_fetch_array($query)){
					?>
					<tr>
						<td align="center"><input type="checkbox" value="<?php echo $row['id']; ?>" name="id[]"></td>
						<td><?php echo $row['username']; ?></td>
						<td><?php echo $row['nome']; ?></td>
						<td><?php echo $row['email']; ?></td>
						<td><?php echo $row['telefone']; ?></td>
						<td><?php echo $row['numerosage']; ?></td>
						<td><?php echo $row['estado']; ?></td>
						<td><?php echo $row['type']; ?></td>
					</tr>
					<?php
				}
			
			?>
			</tbody>
		</table>
		<div class="form-group row">
		<button formaction="editar.php" type="submit" class="btn btn-primary">Editar</button> ||
		<button type="submit" class="btn btn-danger" onclick="return confirmDelete()">Apagar</button>
		
		<div class="col-xs-2">
		<form action="estado.php" method="post">
		<select class="form-control" name="estado" id="estado">
		  <option value="Ativa">Ativar</option>
		  <option value="Desativa">Desativar</option>
		  <option value="Banida">Banir</option>
		</select>
		<br>
		
		<button formaction="estado.php" type="submit" class="btn btn-danger">Alterar Estado</button>

		</form>
		</div>
		<div class="col-xs-2">
		<select class="form-control" name="tipo" id="tipo">
		  <option value="user">User</option>
		  <option value="admin">Admin</option>
		</select>
		
		<br>
		<button formaction="tipo.php" type="submit" class="btn btn-danger">Alterar Tipo</button>
		</div>
		</div>
		
		</form>
		
	</div>
</div>
                            </div>
                        </div>
                    </center>
                </div>
            </div>
        </div>
    </header>
	
    <!-- Footer-Area -->
    <footer class="footer-area">
                    <div class="h-100 row align-items-center">
                        <div class="footer-text">
                            <!--<h4 class="upper"><u>Parceiros</u></h4>-->
							<img src="/partners/microsoft.png" alt="Microsoft" height="100" width="100">&emsp;
                            <img src="/partners/zebra.png" alt="SAGE" height="100" width="100">&emsp;
							<img src="/partners/silver.png" alt="SAGE" height="110" width="120">&emsp;
							<img src="/partners/xd.png" alt="XD" height="100" width="100">
                        </div>
                    </div>
        <!--<div class="footer-top section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-3">
                        <div class="footer-text">
                            <h4 class="upper">Classic</h4>
                            <p>If you are going to use a passage of Lorem Ipsum, you need to be sure</p>
                            <div class="social-menu">
                                <a href="#"><i class="icofont icofont-social-facebook"></i></a>
                                <a href="#"><i class="icofont icofont-social-twitter"></i></a>
                                <a href="#"><i class="icofont icofont-social-google-plus"></i></a>
                                <a href="#"><i class="icofont icofont-social-linkedin"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2 col-md-offset-1">
                        <div class="footer-single">
                            <h4 class="upper">News</h4>
                            <ul>
                                <li><a href="#">Subsciption</a></li>
                                <li><a href="#">New Apps</a></li>
                                <li><a href="#">Download now</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2">
                        <div class="footer-single">
                            <h4 class="upper">Company</h4>
                            <ul>
                                <li><a href="#">Screenshot</a></li>
                                <li><a href="#">Fetures</a></li>
                                <li><a href="#">Price</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2">
                        <div class="footer-single">
                            <h4 class="upper">Resources</h4>
                            <ul>
                                <li><a href="#">Support</a></li>
                                <li><a href="#">Contact</a></li>
                                <li><a href="#">Privacy &amp; Term</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2">
                        <div class="footer-single">
                            <h4 class="upper">Solutions</h4>
                            <ul>
                                <li><a href="#">Bug Fixing</a></li>
                                <li><a href="#">Upgrade</a></li>
                                <li><a href="#">Malware Protect</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        <p class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Webmania, LDA</p>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer-Area / -->


    <!--Vendor-JS-->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/bars.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/counterup.min.js"></script>
    <script src="js/easypiechart.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/scrollUp.min.js"></script>
    <script src="js/magnific-popup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="js/main.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDXZ3vJtdK6aKAEWBovZFe4YKj1SGo9V20&callback=initMap"></script>
    <script src="js/maps.js"></script>
</body>

</html>
<?php
}else{
	header("location: /users/login.php");
}
?>