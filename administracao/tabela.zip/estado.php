<?php
	include('conn.php');

	$estado = $_POST['estado'];
	if(isset($_POST['id'])){
		foreach ($_POST['id'] as $id):
		
			mysqli_query($conn,"UPDATE accounts SET estado='$estado' WHERE id='$id'");
		
		endforeach;
		
		header('location:index.php');
	}else{
		?>
		<script>
			window.alert('Selecione a conta que pretende alterar');
			window.location.href='index.php';
		</script>
		<?php
	}
	
	
?>