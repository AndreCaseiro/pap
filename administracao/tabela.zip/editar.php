<?php
session_start();
if (isset($_SESSION['admin'])) {
?>

<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Icons -->
	<meta property="og:url" content="http://lipis.github.io/bootstrap-social/" />
    <meta property="og:image" content="http://lipis.github.io/bootstrap-social/assets/img/bootstrap-social.png" />
	<!-- Title -->
    <title>Webmania</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/font-awesome.css" rel="stylesheet">
    <link href="assets/css/docs.css" rel="stylesheet" >
    <link href="bootstrap-social.css" rel="stylesheet" >
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="shortcut icon" type="image/ico" href="images/favicon.ico" sizes="32x32"/>
    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/icofont.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
      #map {
        width: 100%;
        height: 400px;
        background-color: grey;
      }
    </style>
</head>

<body data-spy="scroll" data-target=".mainmenu-area">
    <!--Preloader-->
    <div class="preloader">
        <div class="spinner"></div>
    </div>

    <!-- Mainmenu-Area -->
    <nav class="navbar mainmenu-area" data-spy="affix" data-offset-top="197">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="navbar-header smoth">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainmenu">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="#home-area"><img style="width:100px;height:40px;" src="images/logo2.png" alt=""></a>
                    </div>
                    <div class="collapse navbar-collapse navbar-right" id="mainmenu">
                        <ul class="nav navbar-nav navbar-right help-menu">
							<?php  if (isset($_SESSION['username'])==false) : ?>
                            <li><a href="/users/login.php"><i class="icofont icofont-user-alt-4"></i></a></li>
							<?php endif ?>
							<?php  if (isset($_SESSION['username'])) : ?>
							<li><a href="/users/logout.php"><i class="icofont icofont-user-alt-4"></i><?php echo $_SESSION['username']; ?>, Logout</a></li>
							<?php endif ?>
                        </ul>
                        <ul class="nav navbar-nav primary-menu">
                            <li><a href="/index.php#home-area">Início</a></li>
							<li><a href="/index.php#empresa-area">A Empresa</a></li>
                            <li><a href="/index.php#service-area">Serviços</a></li>
                            <li><a href="/index.php#apoiotecnico-area">Apoio Técnico</a></li>
                            <li><a href="/index.php#contact-area">Contactos</a></li>
							<?php  if (isset($_SESSION['admin'])) : ?>
							<li><a href="/assistencias/index.php">Consultar Assistências</a></li>
							<?php endif ?>
                        </ul>
                    </div>
					<div class="collapse navbar-collapse navbar-right" id="mainmenu">
					<ul class="nav navbar-nav primary-menu">
				<?php  if (isset($_SESSION['username'])) : ?>
							<li><a href="/conta/password.php">Alterar Password</a></li>
							<li><a href="/conta/email.php">Alterar Email</a></li>
							<li><a href="/tickets/index.php">Tickets</a></li>
							<li><a href="/tickets/usertickets/index.php">Consultar Tickets</a></li>
				<?php endif ?>
				<?php  if (isset($_SESSION['admin'])) : ?>
							<li><a href="/tickets/admintickets/index.phpindex.php">Gestão de Tickets</a></li>
							<li class="active"><a href="index.php">Contas</a></li>
				<?php endif ?>
							</ul>
				</div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Mainmenu-Area-/ -->


<header class="header-area overlay" id="home-area">
        <div class="vcenter">
            <div class="container">
                <div class="row">
                    <center>
                        <div class="header-text">
                            <div class="wow fadeInUp" data-wow-delay="0.5s">

<?php
include('conn.php');

//header("Content-Type: text/html; charset=ISO-8859-1",true);
if(isset($_POST['id'])){
foreach ($_POST['id'] as $id):
$query = mysqli_query($conn, "SELECT * FROM accounts WHERE id='$id'");
while($row=mysqli_fetch_array($query)){
	$nome = $row['nome'];
	$username = $row['username'];
?>

<form class="form-horizontal" method="post" action="editarquery.php<?php echo '?id='.$id; ?>"  enctype="multipart/form-data">
                                
								<div class="input-group">
                                    <label class="control-label">Username:</label>
                                     <div class="controls">
									<?php
									echo "
                                        <input type='text' class='form-control' cols='50' rows='15' name='username' required value='$username'>
									";
									?>
                                    </div>
                                </div>
								<div class="input-group">
                                    <label class="control-label">Nome:</label>
                                    <div class="controls">
									<?php
									echo "
                                        <input type='text' class='form-control' cols='50' rows='15' name='nome' required value='$nome'>
									";
									?>
                                    </div>
                                </div>
								<div class="input-group">
                                    <label class="control-label" for="inputEmail">Email:</label>
                                    <div class="controls">
                                        <input type="text" class="form-control" cols="50" rows="15" name="email" required value=<?php echo $row['email']; ?>>
                                    </div>
                                </div>
								<div class="input-group">
                                    <label class="control-label" for="inputTelefone">Telefone:</label>
                                    <div class="controls">
                                        <input type="text" class="form-control" cols="50" rows="15" name="telefone" value=<?php echo $row['telefone']; ?>>
                                    </div>
                                </div>
								<div class="input-group">
                                    <label class="control-label" for="inputSAGE">Nº Cliente SAGE:</label>
                                    <div class="controls">
                                        <input type="text" class="form-control" cols="50" rows="15" name="numerosage" value=<?php echo $row['numerosage']; ?>>
                                    </div>
                                </div>
                                <div class="input-group">
                                    <label class="control-label" for="inputPassword">Password:</label>
                                    <div class="controls">
                                        <input type="password" class="form-control" cols="50" rows="15" name="password">
                                    </div>
                                </div>
								<br>
								 <div class="input-group">
                                    <div class="controls">
                                        <button type="submit" name="update" class="bttn bttn-sm bttn-default">Editar</button>
                                    </div>
                                </div>
                            </form>
<?php 

}
endforeach;
}else{
?>
		<script>
			window.alert('Selecione a conta que pretende editar');
			window.location.href='index.php';
		</script>
		
<?php
	}
?>



                            </div>
                        </div>
                    </center>
                </div>
            </div>
        </div>
    </header>
   <!-- Footer-Area -->
    <footer class="footer-area">
                    <div class="h-100 row align-items-center">
                        <div class="footer-text">
                            <!--<h4 class="upper"><u>Parceiros</u></h4>-->
							<img src="/partners/microsoft.png" alt="Microsoft" height="100" width="100">&emsp;
                            <img src="/partners/zebra.png" alt="SAGE" height="100" width="100">&emsp;
							<img src="/partners/silver.png" alt="SAGE" height="110" width="120">&emsp;
							<img src="/partners/xd.png" alt="XD" height="100" width="100">
                        </div>
                    </div>
        <!--<div class="footer-top section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-3">
                        <div class="footer-text">
                            <h4 class="upper">Classic</h4>
                            <p>If you are going to use a passage of Lorem Ipsum, you need to be sure</p>
                            <div class="social-menu">
                                <a href="#"><i class="icofont icofont-social-facebook"></i></a>
                                <a href="#"><i class="icofont icofont-social-twitter"></i></a>
                                <a href="#"><i class="icofont icofont-social-google-plus"></i></a>
                                <a href="#"><i class="icofont icofont-social-linkedin"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2 col-md-offset-1">
                        <div class="footer-single">
                            <h4 class="upper">News</h4>
                            <ul>
                                <li><a href="#">Subsciption</a></li>
                                <li><a href="#">New Apps</a></li>
                                <li><a href="#">Download now</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2">
                        <div class="footer-single">
                            <h4 class="upper">Company</h4>
                            <ul>
                                <li><a href="#">Screenshot</a></li>
                                <li><a href="#">Fetures</a></li>
                                <li><a href="#">Price</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2">
                        <div class="footer-single">
                            <h4 class="upper">Resources</h4>
                            <ul>
                                <li><a href="#">Support</a></li>
                                <li><a href="#">Contact</a></li>
                                <li><a href="#">Privacy &amp; Term</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2">
                        <div class="footer-single">
                            <h4 class="upper">Solutions</h4>
                            <ul>
                                <li><a href="#">Bug Fixing</a></li>
                                <li><a href="#">Upgrade</a></li>
                                <li><a href="#">Malware Protect</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        <p class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Webmania, LDA</p>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer-Area / -->


    <!--Vendor-JS-->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/bars.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/counterup.min.js"></script>
    <script src="js/easypiechart.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/scrollUp.min.js"></script>
    <script src="js/magnific-popup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="js/main.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDXZ3vJtdK6aKAEWBovZFe4YKj1SGo9V20&callback=initMap"></script>
    <script src="js/maps.js"></script>
</body>

</html>
<?php
}else{
	header("location: /users/login.php");
}
?>